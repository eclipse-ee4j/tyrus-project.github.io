WebSocket RI bundle

Content of this bundle is supposed to be put into glassfish4/glassfish/modules directory or as libraries
to war file to be deployed on Servlet 3.1 compliant container. Tyrus 1.0-rc2 will be present in Glassfish
promoted build 4.0-b84, which will be available on http://dlc.sun.com.edgesuite.net/glassfish/4.0/promoted/glassfish-4.0-b84.zip
